System.register([], (function () {
	'use strict';
	return {
		execute: (function () {

			lively.FreezerRuntime.recorderFor("lively.shell/index.js");

		})
	};
}));
