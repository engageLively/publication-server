System.register(['./__rootModule___commonjs-entry-a506097e.js'], (function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.g4);
		}],
		execute: (function () {



		})
	};
}));
