System.register(['./__rootModule___commonjs-entry-a506097e.js', './ui.cp-b6d4e422.js', './loading-indicator.cp-e70d35e0.js', './index-5f8d7e19.js', './editor-modes-68327020.js', './search-fdfee5ce.js'], (function (exports) {
  'use strict';
  var createFilter, dataToEsm;
  return {
    setters: [function () {}, function (module) {
      createFilter = module.W;
      dataToEsm = module.X;
    }, function () {}, function () {}, function () {}, function () {}],
    execute: (function () {

      exports('default', json);

      function json(options) {
        if ( options === void 0 ) options = {};

        var filter = createFilter(options.include, options.exclude);
        var indent = 'indent' in options ? options.indent : '\t';

        return {
          name: 'json',

          // eslint-disable-next-line no-shadow
          transform: function transform(code, id) {
            if (id.slice(-5) !== '.json' || !filter(id)) { return null; }

            try {
              var parsed = JSON.parse(code);
              return {
                code: dataToEsm(parsed, {
                  preferConst: options.preferConst,
                  compact: options.compact,
                  namedExports: options.namedExports,
                  indent: indent
                }),
                map: { mappings: '' }
              };
            } catch (err) {
              var message = 'Could not parse JSON file';
              this.error({ message: message, id: id, cause: err });
              return null;
            }
          }
        };
      }

    })
  };
}));
