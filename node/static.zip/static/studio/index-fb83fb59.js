System.register(['./app-48ae10b8.js', './__rootModule___commonjs-entry-d88ef94c.js', './index-0fc4a522.js', './loading-indicator.cp-b3c8d0fe.js', './ui.cp-bc3a4b16.js', './editor-modes-f49538f6.js', './search-ce263b75.js', './messages.cp-bed466d0.js', './code-search.cp-a0bc8e2a.js', './editor-plugin-be6dabc1.js', './dialogs.cp-62ee6598.js', 'lively.collab', './canvas-c88985d1.js', './object-classes-62003f5e.js', './morph-to-image-b0c0c735.js'], (function (exports) {
	'use strict';
	var GalyleoDashboardStudio;
	return {
		setters: [function (module) {
			GalyleoDashboardStudio = module.G;
			exports('GalyleoDashboardStudio', module.G);
		}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}, function () {}],
		execute: (function () {

			var __varRecorder__ = lively.FreezerRuntime.recorderFor("engageLively--galyleo-dashboard/studio/int/en/index.js");
			__varRecorder__.GalyleoDashboardStudio = GalyleoDashboardStudio;

		})
	};
}));
