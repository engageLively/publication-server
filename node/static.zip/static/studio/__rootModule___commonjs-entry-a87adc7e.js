System.register(['./__rootModule___commonjs-entry-d88ef94c.js'], (function (exports) {
	'use strict';
	return {
		setters: [function (module) {
			exports('renderFrozenPart', module.g5);
		}],
		execute: (function () {



		})
	};
}));
