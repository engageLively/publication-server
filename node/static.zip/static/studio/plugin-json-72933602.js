System.register(['./__rootModule___commonjs-entry-d88ef94c.js', './ui.cp-bc3a4b16.js', './loading-indicator.cp-b3c8d0fe.js', './index-0fc4a522.js', './editor-modes-f49538f6.js', './search-ce263b75.js'], (function (exports) {
  'use strict';
  var createFilter, dataToEsm;
  return {
    setters: [function () {}, function (module) {
      createFilter = module.Y;
      dataToEsm = module.Z;
    }, function () {}, function () {}, function () {}, function () {}],
    execute: (function () {

      exports('default', json);

      function json(options) {
        if ( options === void 0 ) options = {};

        var filter = createFilter(options.include, options.exclude);
        var indent = 'indent' in options ? options.indent : '\t';

        return {
          name: 'json',

          // eslint-disable-next-line no-shadow
          transform: function transform(code, id) {
            if (id.slice(-5) !== '.json' || !filter(id)) { return null; }

            try {
              var parsed = JSON.parse(code);
              return {
                code: dataToEsm(parsed, {
                  preferConst: options.preferConst,
                  compact: options.compact,
                  namedExports: options.namedExports,
                  indent: indent
                }),
                map: { mappings: '' }
              };
            } catch (err) {
              var message = 'Could not parse JSON file';
              this.error({ message: message, id: id, cause: err });
              return null;
            }
          }
        };
      }

    })
  };
}));
